import React from 'react'
import { useState, useEffect } from 'react'

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [allEntry, setAllEntry] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault()
    const newEntry = { email: email, password: password };
    setAllEntry([...allEntry, newEntry]);
    if (email == "asdf") {
      if (password == "asdf") {
        alert("Login Success.")
      } else {
        alert("Invalid Credentials.")
      }
    }
  }

  return (
    <>
      <form action="" >
        <div>
          <label htmlFor="email">Email</label>
          <input onChange={(e) => {
            setEmail(e.target.value)
          }} type="text" name="email" id="email " autoComplete="off" value={email} />
        </div>
        <div>
          <label htmlFor="password">Password</label>
          <input onChange={(e) => {
            setPassword(e.target.value)
          }} type="password" name="password" id="passWord" autoComplete="off" value={password} />
        </div>

        <button type="submit" onClick={handleSubmit}>Login</button>
      </form>
      <div>
        {
          allEntry.map((curElem) => {
            return (
              <div className='showData'>
                <p>{curElem.email}</p>
                <p>{curElem.password}</p>
              </div>
            )
          })
        }
      </div>
    </>
  )
}

export default Login